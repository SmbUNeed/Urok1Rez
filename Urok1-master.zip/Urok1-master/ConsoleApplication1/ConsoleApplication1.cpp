﻿#include<iostream>
#include<string>
using namespace std;

int integ = 25;
int teg;

int main()
{
	cout << "sdsfsf";
	wchar_t i1{ L'i' };
	std::wcout << i1 << '\n';

	int c12 = 25;
	char w[] = "west";
	teg = 55;
	string w1 = "Lady";
	int a10 = 20;
	string s1 = "hello";
	char ch1 = 's';
	double d1 = 25;
	float f1 = 25.6;
	int a1, b1, c1;
	char fh = 'A';
	a1 = 25;
	char a5 = 'H';
	string str = "Hello";
	char b5 = 'B';
	int a2, a3;
	int c3 = 18;
	s1 = "hi";
	char b6[] = "lets go";
	int inerg = 22; 
	cout << integ << endl<< inerg <<endl ;
	int teg = 85;
	return 0;
}